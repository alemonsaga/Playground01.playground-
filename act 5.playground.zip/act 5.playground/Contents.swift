import UIKit

Playground - Actividad 5

·Class y Struct
·Extension
·Optional



Actividad Class y Struct

A) Diseñar la clase Persona que contenga dos metodos, el primero "Saludar" que reciba el parámetro nombre y regrese el mensaje el nombre mas el texto "mucho gusto", el segundo metodo "Caminar" que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el numero de pasos caminados.

//declaración de clase

class persona
{
    var estatura:Float, saludo = "mucho gusto"
    var edad:Int, camino = 0
    
    init(estatura:Float, edad:Int)
    {
        self .estatura = estatura
        self .edad = edad
    }
    
    func Caminar(pasos:Int)
    {
        self .camino = 5pasos
    }
    func Hablar(mensaje:String)
    {
        self .saludo = mensaje
    }
}
 
//Instanciar e inicializar
var carlos = Humano(estatura: 1, 8, edad: 38)


B) Diseñar el struct "Pantalla" la cual recibirá como como parametros el ancho y alto de una pantalla como tipo de datos Int con un constructor, para inicializar la estructura.

//Declaración del struct

struct pantalla
{
    var alto: Int
    var ancho: Int
    
    init(alto:Int, ancho:Int)
    {
        self .alto = alto
        self .ancho = ancho
    }
    func QueResolucion() -> (Int, Int)
    {
        return (self .alto, self .ancho)
    }
}

//Instanciar e instalar
var hd = Video (alto: 1024,  ancho: 768)


Extensions

A) Diseñar un extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada)

//declaración extension

extension Int {
    var horas:Int {
        return self*12*30
    }
    func segundos() -> Int {
        return self*24*60
    }
}
//horas a segundos
3.horas
//horas a segundos
3.horas()

B) Diseñar una extensión del tipo de dato String que represente un día de la semana y regrese el numero correspondiente iniciando con Domingo = 1 y finalizando Sábado = 7

//declaración extension

extension String{
    var día de la semana: String {
    return self*Domingo*Sabado
    }
    func numeros() -> String {
        return self*1*7
    }
}
//dias de la semana a numeros
7. dias de la semana
//numeros a dias de la semana
7. dias de la semana a numeros()

Optionals

A) Diseñar una variable opcional para recibir el tipo de dato Int en caso de que exista.

//Optional inicio de variables al momento de declararlas

Int Numeric = 1.2, 1.3, 6.5
char respuesta = "n";
Double pulgada = 5.6;
Int suma = 0;
Double pulgada_a_cm = 0;
Bool continue = false;

B) Para la colección let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200] diseñar una variable opcional para recibir el valor de dias["DF"]

//Optional

var ciudad = ["PUE":300, "MTY":100, "GDL":120]
var existe: Int?

//aplicación
existe = ciudad["DF"]
existe = ciudad["PUE"]

//puente
if let temp = ciudad ["DF"]{
    print("dias")
}else{
    print("dias")
}

var greeting = "Hello, playground"
