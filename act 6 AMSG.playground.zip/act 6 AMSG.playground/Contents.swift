import UIKit

Playground - Actividad 6

·Operadores personalizados
·Subscripts
·Control de errores






Operadores personalizados

A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros

//Antes de valor
prefix operator +++

prefix func +++(valor:Int)->Int
{
    let v = valor + valor
    return v
    
}
+++5
+++2


B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor

//Entre valores
infix operator  |>

func   |>  (a:Int, f:(Int)->Int) -> Int
{
    return f(a)
}
func suma2 (dato:Int)  -> Int
{
    return dato + 2
}

2|>
3|>
4|>
5|>

Subscripts

A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.

//Subscript
let cantidades = [2, 3, 4, 5]

class Cantidad
{
    var valores:[Int]
    init(v:[Int])
    {
        self.valores = v
    }
    subscript(idx:Int) -> Int
    {
        get
        {
            return valores [idx]
        }
        set (nuevoValor)
        {
            valores[idx] = nuevoValor
        }
    }
    
}





B) Crear el Struct para definir u obtener la posición  para los personaje de tipo Enemigo donde cada posición es de tipo CGPoint aplicnado subscritps

//Declaracion del struct

struct enemigo
{
    var alto:78
    var  ancho:17
    
    init(alto:Int, ancho:Int)
    {
        self.alto = alto
        self.ancho = ancho
    }
    func QueResolucion() -> (Int, Int)
    {
        return (self.alto, self.ancho)
    }
    
    
}

Control de Errores

A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]

//Control de errores
let dictError = [1:"a", 2:"b", 3:"c"]

func Existe (idx:Int)
{
    guard let existe = dictError [idx] else {
        print("No existe")
        return
    }
    print("existe \(existe)")
}
Existe(idx: 123)
dictError[123]

var greeting = "Hello, playground"
