import UIKit
Playground - Actividad 4

·Condiciones y ciclos
·Funciones
·Enumeración








Condiciones y Ciclos

A)Declarar la variable "datos" con los valores[3,6,9,2,4,1]







B)realizar el recorrido de la Variable "datos" con la instrucción "for"








C)Encontrar los valores menos a 5












FUNCIONES

A)Crea la función "suma" qué reciba dos parámetros de tipo entero regresando la suma de ambos números





B)Crear la función "potencia" qué reciba dos parámetros de tipo entero, el primer parámetro para el número base y el segundo la potencia a elevar, regresando el resultado de la potencia









ENUMERACIONES

A)Crea la enumeración "meses" para definir tipos de datos basados en los meses del año





B)Crear la función "numeroMES" qué reciba el tipo de dato "meses" y regrese el numero del mes correspondiente







C)Para regresar el número de mes correspondiente utilizar la "switch"

var greeting = "Hello, playground"
