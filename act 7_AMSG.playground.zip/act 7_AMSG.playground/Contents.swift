import UIKit

//Playground - Actividad 7

//·Valor por tipo y por referencia
//·Funciones personalizadas Y Genericos
//·Funciones de la biblioteca Swift para Arreglos



//Valorportipoyporreferencia

//A)Parala colección"varcosto_referencia:[Float] = [8.3,10.5,9.9]",aplicarelimpuestodel16%atravésderecorrer lacolección"costo_referencia"paraaplicarelimpuestoacada cantidad,crearunafunciónImpuestoquerecibecomoparámetrola colecciónyregreseaplicadoelimpuestoacadacantidad.

//Programación Funcional

//varnumeros=[8,13,10,5,9.9]
//varcosto_referencia:[Float]=16%

//foriinnumeros
//{numeros[Indice]=í*16%Indices+=1}

//numeros

//funcImpuesto(arreglo:[Int]->[Int]
//{var resultado:[Int]=[]
//foriinarreglo
//{resultado.append (i*16%)}
//returnresultado}
//PorDos(arrego:numeros)
//numeros


//B)Crearlafunción"sumaTres"querecibaunafuncióncondosvaloresasumaryunsegundoparametroparasumareltercernúmero.


//Programacion funcional

//varnumeros=[1, 2, 3]
//varindice:Int=0

//foriinnumeros
//{numeros[indice]=i*2}

//numeros

//funcPorDos(arreglo):[Int])->[Int]
//{varresultado:[Int]=[]
//foriinarreglo
//{resultado.append(i*2)}
//returnresultado}

//PorDos(arreglo:numeros)
//numeros

//FuncionespersonalizadasyGenéricos

//A)Generics:Crearlafuncióngenéricaparaintercambiar valores entre dos variables del mismo tipo.

//Mi función personalizada
//extension Array
//{funcSAcumulada<t>(inicial:T,acumula:(T,
//Element)->T)->T
//{varrespuesta:T=inicialforvalorinSelf
//{respuesta=acumula(respuesta,valor)}
//returnrespuesta}}

//vardatos=[1,2,3,4,5]
//varletras=["a","e","i","o","u"]
//datos.SAcumulada(inicial: 0){(a,b)ina+b}
//letras.SAcumulada(inicial: ""){(a, b)}  in a + b}


//B)Funciónpersonalizada:Crearlafunción"Transformar"quereciba comoparámetrounacoleccióndetipoInt"var datos=[3,7,9,2]"y unafunciónquetransformecadavalordelacoleciónenuna operacióndefinidafueradelafunciónregresandounacoleccióntransformada.


//Mifunciónpersonalizada
//extensionArray
//{funcTransformar<T>(inicial:T,acumulada:(T,Element) -> T)->T{varrespuesta:T=inicial
//forvalorinSelf
//{respuesta=acumula(respuesta,valor)}
//returnrespuesta}}

//vardatos=[3,7,9,2]
//varletras=["a","e","i","o","u"]
//datos.SAcumulada(inicial:0){(a,bina+b}
//letras.SAcumulada(inicial:""){(a,b)ina+b}

//BibliotecadeSwift

//A)Aplicar la función de librería de Swift "map" para la colección var precios = [4.2, 5.3, 8.2, 4.5] y aplicar el impuesto de 16% y asignarla a la variable "impuesto"

//Biblioteca de Swift

//letdatos2=[4.2,5.3,8.2,4.5]

//Sumar cada elemnto por 16%
//var"impuesto"=datos16.map{ainreturna+16}
//sumale16

//Los elementos mayores a 3
//varprecio=datos2.filter{a in a > 3}
//filtro

//Suma acumulada
//varacumulado=datos2.reduce(0){a,b)ia+b}
//acumulado

//ordenado de mayor a menor
//varorden=datos2.sorted{(a,b)->Boolina>b}
//orden


//B)Aplicar la función de la librería de Swift "filter" para la colección resultante "impuesto" del paso A, en donde se obtengas solo los precios mayores a 6.0 y asignarlos a la variable "precio_menor"


//Combinación de métodos
//var"precio_menor"=datos2.map{aina*2}.filter{aina>3}.reduce(0){(a,b)ina+ b}
//porDosFiltroAcumulado


